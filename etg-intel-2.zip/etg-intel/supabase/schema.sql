-- ============================================================
-- ETG Project Intelligence — Supabase Schema
-- Run this entire file in the Supabase SQL editor once.
-- ============================================================

-- Projects table
create table if not exists projects (
  id            uuid primary key default gen_random_uuid(),
  name          text not null,
  location      text,
  value         text,
  value_numeric bigint,
  sector        text check (sector in ('medical','school','other')),
  stage         text check (stage in ('planning','bidding','tender','awarded')),
  description   text,
  bid_deadline  text,
  contract_type text,
  project_number text,
  architect     text,
  keywords      text[]  default '{}',
  contacts      jsonb   default '[]',
  source        text,
  source_url    text,
  below_threshold boolean default false,
  notes         text,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- Research runs log (so digest can compare "new this week")
create table if not exists research_runs (
  id         uuid primary key default gen_random_uuid(),
  ran_at     timestamptz default now(),
  source     text,
  projects_found int default 0,
  summary    text
);

-- Digest log (so we don't double-send)
create table if not exists digest_log (
  id       uuid primary key default gen_random_uuid(),
  sent_at  timestamptz default now(),
  projects_included int,
  recipient text
);

-- Auto-update updated_at
create or replace function update_updated_at()
returns trigger as $$
begin new.updated_at = now(); return new; end;
$$ language plpgsql;

create trigger projects_updated_at
  before update on projects
  for each row execute function update_updated_at();

-- RLS: enable but allow all for now (add user auth scoping later if needed)
alter table projects enable row level security;
alter table research_runs enable row level security;
alter table digest_log enable row level security;

-- Simple open policy — tighten once you add per-user auth
create policy "allow all" on projects for all using (true) with check (true);
create policy "allow all" on research_runs for all using (true) with check (true);
create policy "allow all" on digest_log for all using (true) with check (true);

-- Helpful index for filtering
create index if not exists idx_projects_stage on projects(stage);
create index if not exists idx_projects_sector on projects(sector);
create index if not exists idx_projects_created on projects(created_at desc);
create index if not exists idx_projects_keywords on projects using gin(keywords);
