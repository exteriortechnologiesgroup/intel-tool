import { NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase'
import { generateDigestSummary } from '@/lib/extract'
import type { Project } from '@/lib/types'

export const maxDuration = 60

export async function POST() {
  const supabase = createServerClient()

  // Get projects from the last 7 days
  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()
  const { data: weekProjects, error } = await supabase
    .from('projects')
    .select('*')
    .gte('created_at', sevenDaysAgo)
    .order('created_at', { ascending: false })

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  const projects = (weekProjects ?? []) as Project[]

  if (!projects.length) {
    return NextResponse.json({
      summary: 'No new projects were added in the last 7 days.',
      projects: [],
      qualifying: 0,
      withKeywords: 0,
      medical: 0,
      school: 0,
    })
  }

  const summary = await generateDigestSummary(projects)

  return NextResponse.json({
    summary,
    projects,
    qualifying: projects.filter(p => !p.below_threshold).length,
    withKeywords: projects.filter(p => p.keywords.length > 0).length,
    medical: projects.filter(p => p.sector === 'medical').length,
    school: projects.filter(p => p.sector === 'school').length,
  })
}
